import { useSelector } from 'react-redux';
import { Link, useLocation } from 'react-router-dom';

const Header = () => {
  const total = useSelector(state => state.cart.totalQuantity);
  const location = useLocation();

  return (
    <header>
      {location.pathname !== '/' && <Link to="/">Home</Link>}
      {location.pathname !== '/products' && <Link to="/products">Products</Link>}
      {location.pathname !== '/cart' && <Link to="/cart">🛒 {total}</Link>}
    </header>
  );
};

export default Header;