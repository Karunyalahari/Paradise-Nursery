import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addToCart } from '../redux/cartSlice';

const ProductCard = ({ product }) => {
  const dispatch = useDispatch();
  const cartItems = useSelector(state => state.cart.cartItems);
  const isAdded = cartItems.some(item => item.id === product.id);

  return (
    <div className="card">
      <img src={product.image} alt={product.name} width={100} />
      <h3>{product.name}</h3>
      <p>${product.price}</p>
      <button disabled={isAdded} onClick={() => dispatch(addToCart(product))}>
        {isAdded ? 'Added' : 'Add to Cart'}
      </button>
    </div>
  );
};

export default ProductCard;