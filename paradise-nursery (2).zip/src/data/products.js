export const products = [
  { id: 1, name: 'Aloe Vera', price: 10, image: '/images/aloe.jpg', category: 'Succulents' },
  { id: 2, name: 'Snake Plant', price: 15, image: '/images/snake.jpg', category: 'Indoor' },
  { id: 3, name: 'Bamboo Palm', price: 18, image: '/images/bamboo.jpg', category: 'Indoor' },
  { id: 4, name: 'Peace Lily', price: 12, image: '/images/lily.jpg', category: 'Flowering' },
  { id: 5, name: 'Spider Plant', price: 8, image: '/images/spider.jpg', category: 'Succulents' },
  { id: 6, name: 'Money Plant', price: 9, image: '/images/money.jpg', category: 'Flowering' },
];