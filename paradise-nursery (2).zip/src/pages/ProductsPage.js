import { products } from '../data/products';
import ProductCard from '../components/ProductCard';

const ProductsPage = () => {
  return (
    <div className="products-container">
      {products.map(p => (
        <ProductCard key={p.id} product={p} />
      ))}
    </div>
  );
};

export default ProductsPage;