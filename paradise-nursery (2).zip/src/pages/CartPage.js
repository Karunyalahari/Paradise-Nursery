import { useSelector } from 'react-redux';
import CartItem from '../components/CartItem';
import { Link } from 'react-router-dom';

const CartPage = () => {
  const { cartItems, totalQuantity, totalAmount } = useSelector(state => state.cart);

  return (
    <div>
      <h2>Shopping Cart</h2>
      <p>Total Plants: {totalQuantity}</p>
      <p>Total Cost: ${totalAmount}</p>
      {cartItems.map(item => <CartItem key={item.id} item={item} />)}
      <Link to="/products"><button>Continue Shopping</button></Link>
      <button>Checkout (Coming Soon)</button>
    </div>
  );
};

export default CartPage;