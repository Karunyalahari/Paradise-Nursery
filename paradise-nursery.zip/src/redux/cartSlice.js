import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  cartItems: [],
  totalQuantity: 0,
  totalAmount: 0,
};

const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    addToCart(state, action) {
      const item = action.payload;
      const existing = state.cartItems.find(p => p.id === item.id);
      if (!existing) {
        state.cartItems.push({ ...item, quantity: 1 });
        state.totalQuantity++;
        state.totalAmount += item.price;
      }
    },
    increment(state, action) {
      const item = state.cartItems.find(p => p.id === action.payload);
      if (item) {
        item.quantity++;
        state.totalQuantity++;
        state.totalAmount += item.price;
      }
    },
    decrement(state, action) {
      const item = state.cartItems.find(p => p.id === action.payload);
      if (item && item.quantity > 1) {
        item.quantity--;
        state.totalQuantity--;
        state.totalAmount -= item.price;
      }
    },
    removeItem(state, action) {
      const item = state.cartItems.find(p => p.id === action.payload);
      if (item) {
        state.totalQuantity -= item.quantity;
        state.totalAmount -= item.quantity * item.price;
        state.cartItems = state.cartItems.filter(p => p.id !== item.id);
      }
    },
  },
});

export const { addToCart, increment, decrement, removeItem } = cartSlice.actions;
export default cartSlice.reducer;