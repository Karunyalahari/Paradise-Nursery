import React from 'react';
import { Link } from 'react-router-dom';

const LandingPage = () => (
  <div style={{ backgroundImage: 'url(/images/bg.jpg)', padding: '50px' }}>
    <h1>Paradise Nursery</h1>
    <p>We bring your home to life with vibrant green plants!</p>
    <Link to="/products">
      <button>Get Started</button>
    </Link>
  </div>
);

export default LandingPage;