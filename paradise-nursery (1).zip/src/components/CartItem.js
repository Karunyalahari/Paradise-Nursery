import { useDispatch } from 'react-redux';
import { increment, decrement, removeItem } from '../redux/cartSlice';

const CartItem = ({ item }) => {
  const dispatch = useDispatch();

  return (
    <div className="cart-item">
      <img src={item.image} alt={item.name} width={50} />
      <div>{item.name}</div>
      <div>${item.price}</div>
      <div>
        <button onClick={() => dispatch(decrement(item.id))}>-</button>
        {item.quantity}
        <button onClick={() => dispatch(increment(item.id))}>+</button>
      </div>
      <button onClick={() => dispatch(removeItem(item.id))}>Delete</button>
    </div>
  );
};

export default CartItem;